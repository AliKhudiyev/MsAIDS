function f = SphereNew(x)

f = sum(x.^2);
end