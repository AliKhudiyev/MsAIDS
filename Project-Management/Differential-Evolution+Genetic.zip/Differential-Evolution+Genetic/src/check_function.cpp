#include <cmath>

int main(){
    double* x;
    return x[0]+1;
}
