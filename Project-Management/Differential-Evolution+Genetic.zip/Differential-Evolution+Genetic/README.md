# Differential Evolution

Read the specification and design documents for more information.
