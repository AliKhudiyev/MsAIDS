#!/bin/zsh

touch {a..e}{3..5}
mkdir dr{2..5}