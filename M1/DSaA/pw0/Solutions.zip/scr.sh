#!/bin/zsh

date; ls

printf "names: $(whoami)\n"