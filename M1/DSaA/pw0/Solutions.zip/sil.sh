#!/bin/zsh

rm {a,b,c,d,e}{3,4,5}
rmdir dr{2,3,4,5}