# Exercise 4

1. echo Today is $(date)
2. echo Today is $(date +%d/%m/%Y)

# Exercise 5

1. head -n 10 EX5
2. head -n 15 EX5
3. tail -n 20 EX5
4. less EX5
5. line/words/bytes of EX5

# Exercise 6

1. sort EX6
2. sort EX6 | uniq -u
3. sort EX6 | uniq -u > newEX6

# Exercise 7

1. tar xvf EX7.tar.gz
2. ls -R EX7
3. find EX7 -exec file {} \;
